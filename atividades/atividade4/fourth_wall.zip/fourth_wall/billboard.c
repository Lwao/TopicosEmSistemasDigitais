#define display (long*) 0x0002000

void main () 
{
	long count=0;
	while(1)
	{
		// send count to register
		*display = count;
		count++;
	}
}